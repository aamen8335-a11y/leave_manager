# Leave Manager (Arabic/English)

Simple bilingual starter ready for Codemagic.