
import 'package:flutter/material.dart';
import '../l10n.dart';

class RequestScreen extends StatelessWidget {
  RequestScreen({super.key});

  final _types = const ['سنوية', 'مرضية', 'بدون راتب', 'أخرى'];

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Padding(
      padding: const EdgeInsets.all(16),
      child: ListView(
        children: [
          Text(t.tr('create_request'), style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            items: _types.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (v) {},
            decoration: InputDecoration(labelText: t.tr('type')),
          ),
          const SizedBox(height: 12),
          TextField(decoration: InputDecoration(labelText: t.tr('start_date'))),
          const SizedBox(height: 12),
          TextField(decoration: InputDecoration(labelText: t.tr('end_date'))),
          const SizedBox(height: 12),
          TextField(maxLines: 3, decoration: InputDecoration(labelText: t.tr('notes'))),
          const SizedBox(height: 16),
          FilledButton(onPressed: () {}, child: Text(t.tr('submit'))),
        ],
      ),
    );
  }
}
