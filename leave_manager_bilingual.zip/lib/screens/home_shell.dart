
import 'package:flutter/material.dart';
import '../l10n.dart';
import 'request_screen.dart';
import 'approvals_screen.dart';
import 'dashboard_screen.dart';
import 'settings_screen.dart';

class HomeShell extends StatefulWidget {
  final void Function(Locale) onChangeLocale;
  const HomeShell({super.key, required this.onChangeLocale});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final pages = [
      RequestScreen(),
      const ApprovalsScreen(),
      const DashboardScreen(),
      SettingsScreen(onChangeLocale: widget.onChangeLocale),
    ];

    final labels = [
      t.tr('leave_request'),
      t.tr('approvals'),
      t.tr('dashboard'),
      t.tr('settings'),
    ];

    final icons = const [
      Icons.post_add_outlined,
      Icons.verified_outlined,
      Icons.query_stats_outlined,
      Icons.settings_outlined,
    ];

    return Scaffold(
      appBar: AppBar(title: Text(t.tr('app_title'))),
      body: pages[_index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        destinations: List.generate(4, (i) => NavigationDestination(icon: Icon(icons[i]), label: labels[i])),
        onDestinationSelected: (i) => setState(() => _index = i),
      ),
    );
  }
}
