
import 'package:flutter/material.dart';
import '../l10n.dart';

class ApprovalsScreen extends StatelessWidget {
  const ApprovalsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Center(
      child: Text(t.tr('pending_requests')),
    );
  }
}
