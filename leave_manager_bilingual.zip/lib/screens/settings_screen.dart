
import 'package:flutter/material.dart';
import '../l10n.dart';

class SettingsScreen extends StatelessWidget {
  final void Function(Locale) onChangeLocale;
  const SettingsScreen({super.key, required this.onChangeLocale});

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        ListTile(
          title: Text(t.tr('language')),
          trailing: DropdownButton<String>(
            value: Localizations.localeOf(context).languageCode,
            items: [
              DropdownMenuItem(value: 'ar', child: Text(t.tr('arabic'))),
              DropdownMenuItem(value: 'en', child: Text(t.tr('english'))),
            ],
            onChanged: (v) => onChangeLocale(Locale(v ?? 'ar')),
          ),
        ),
      ],
    );
  }
}
