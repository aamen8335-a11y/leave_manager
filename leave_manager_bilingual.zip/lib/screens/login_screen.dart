
import 'package:flutter/material.dart';
import '../l10n.dart';

class LoginScreen extends StatelessWidget {
  final VoidCallback onLogin;
  final void Function(Locale) onChangeLocale;

  const LoginScreen({super.key, required this.onLogin, required this.onChangeLocale});

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(t.tr('login')),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) => onChangeLocale(Locale(v)),
            itemBuilder: (_) => [
              PopupMenuItem(value: 'ar', child: Text(t.tr('arabic'))),
              PopupMenuItem(value: 'en', child: Text(t.tr('english'))),
            ],
            icon: const Icon(Icons.language),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(decoration: InputDecoration(labelText: t.tr('email'))),
            const SizedBox(height: 12),
            TextField(decoration: InputDecoration(labelText: t.tr('password')), obscureText: true),
            const SizedBox(height: 20),
            FilledButton(onPressed: onLogin, child: Text(t.tr('sign_in'))),
          ],
        ),
      ),
    );
  }
}
