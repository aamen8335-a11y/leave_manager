
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'l10n.dart';
import 'screens/login_screen.dart';
import 'screens/home_shell.dart';

void main() {
  runApp(const LeaveApp());
}

class LeaveApp extends StatefulWidget {
  const LeaveApp({super.key});
  @override
  State<LeaveApp> createState() => _LeaveAppState();
}

class _LeaveAppState extends State<LeaveApp> {
  Locale _locale = const Locale('ar');

  void _setLocale(Locale locale) {
    setState(() => _locale = locale);
  }

  @override
  Widget build(BuildContext context) {
    final isArabic = _locale.languageCode == 'ar';
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Leave Manager',
      locale: _locale,
      supportedLocales: const [Locale('en'), Locale('ar')],
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ],
      localeResolutionCallback: (locale, supported) {
        if (locale == null) return _locale;
        for (var s in supported) {
          if (s.languageCode == locale.languageCode) return s;
        }
        return supported.first;
      },
      home: Directionality(
        textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
        child: LoginScreen(onLogin: () {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (_) => HomeShell(onChangeLocale: _setLocale)),
          );
        }, onChangeLocale: _setLocale),
      ),
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        fontFamily: isArabic ? 'NotoNaskhArabic' : null,
      ),
    );
  }
}
